# coding=utf-8
from zope.viewlet.interfaces import IViewletManager

class IDailyTopicsDigestVM(IViewletManager):
    ''' Viewlet manager for daily topics digests '''

class IWeeklyTopicsDigestVM(IViewletManager):
    ''' Viewlet manager for weekly topics digests '''
