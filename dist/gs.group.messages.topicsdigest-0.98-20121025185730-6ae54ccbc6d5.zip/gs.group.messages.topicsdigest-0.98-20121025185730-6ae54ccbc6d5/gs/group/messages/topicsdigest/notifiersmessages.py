# coding=utf-8
from zope.component import createObject, getMultiAdapter
from zope.cachedescriptors.property import Lazy
# TODO Create and use a MessageSender made for notifying groups
from gs.profile.notify.sender import MessageSender
UTF8 = 'utf-8'

class DailyTopicsDigestNotifier(object):
    textTemplateName = 'gs-group-messages-topicsdigest-daily.txt'
    htmlTemplate = 'gs-group-messages-topicsdigest-daily.html'

    def __init__(self, context, request):
        self.context = context
        self.request = request

    @Lazy
    def groupInfo(self):
        retval = createObject('groupserver.GroupInfo', self.context)
        assert retval, 'Could not create the GroupInfo from %s' % self.context
        return retval

    @Lazy
    def textTemplate(self):
        retval = getMultiAdapter((self.context, self.request),
                    name=self.textTemplateName)
        assert retval
        return retval

    @Lazy
    def htmlTemplate(self):
        retval = getMultiAdapter((self.context, self.request),
                    name=self.htmlTemplateName)
        assert retval
        return retval

    def notify(self):
        subject = (u'Topic Digest for %s' % (self.groupInfo.name).encode(UTF8))

