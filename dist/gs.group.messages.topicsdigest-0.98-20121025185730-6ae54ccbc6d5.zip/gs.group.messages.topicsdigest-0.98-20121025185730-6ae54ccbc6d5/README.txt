Introduction
===========

gs.group.messages.topicsdigest provides the notifiers used to construct topic digest emails.
